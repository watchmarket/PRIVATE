let offscreenCreating = null;

// ── Persist auto state ──────────────────────────────────────────
async function getAutoEnabled() {
  return new Promise(r => chrome.storage.local.get('autoEnabled', d => r(!!d.autoEnabled)));
}
async function setAutoEnabled(val) {
  return new Promise(r => chrome.storage.local.set({ autoEnabled: val }, r));
}

async function getGasSettings() {
  return new Promise(r => chrome.storage.local.get('gasSettings', d => r(d.gasSettings || {})));
}

// ── Badge icon ──────────────────────────────────────────────────
function updateBadge(enabled) {
  try {
    chrome.action.setBadgeText({ text: enabled ? 'ON' : 'OFF' });
    chrome.action.setBadgeBackgroundColor({ color: enabled ? '#22c55e' : '#6b7280' });
    chrome.action.setBadgeTextColor({ color: '#ffffff' });
  } catch (_) {}
}

// ── KeepAlive alarm: bangun SW tiap ~24 detik ──────────────────
chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'keepAlive') return;
  const auto = await getAutoEnabled();
  if (!auto) return;
  if (!(await hasDocument())) {
    console.log('[GasBG] Offscreen mati, restart...');
    await startOffscreen();
  }
});

// ── Message handler ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

  if (msg.type === 'TOGGLE_AUTO') {
    const enable = msg.enable;
    // Set badge immediately (synchronous) before any async work
    updateBadge(enable);
    // Simpan settings yang dikirim dari popup sekaligus
    if (msg.settings) chrome.storage.local.set({ gasSettings: msg.settings });
    setAutoEnabled(enable).then(async () => {
      if (enable) {
        await startOffscreen();
      } else {
        await stopOffscreen();
      }
      chrome.runtime.sendMessage({ type: 'AUTO_STATUS', enabled: enable }).catch(() => {});
    });
    sendResponse({ ok: true });
  }

  else if (msg.type === 'FETCH_ONCE') {
    const settingsPromise = msg.settings ? Promise.resolve(msg.settings) : getGasSettings();
    settingsPromise.then(async (settings) => {
      if (msg.settings) chrome.storage.local.set({ gasSettings: msg.settings });
      await sendToOffscreen('FETCH_ONCE', settings);
    });
    sendResponse({ ok: true });
  }

  else if (msg.type === 'SETTINGS_UPDATED') {
    getAutoEnabled().then(async (auto) => {
      if (!auto) return;
      const settings = await getGasSettings();
      if (await hasDocument()) {
        chrome.runtime.sendMessage({ type: 'APPLY_SETTINGS', settings }).catch(() => {});
      }
    });
    sendResponse({ ok: true });
  }

  else if (msg.type === 'GET_AUTO_STATUS') {
    getAutoEnabled().then(auto => sendResponse({ enabled: auto }));
    return true;
  }

  // Offscreen simpan data hasil fetch ke storage
  else if (msg.type === 'SAVE_GAS_DATA') {
    chrome.storage.local.set({ gasLastData: msg.data });
    // Forward ke popup jika terbuka
    chrome.runtime.sendMessage({ type: 'GAS_DATA', data: msg.data }).catch(() => {});
    sendResponse({ ok: true });
  }
});

// ── Restore saat browser restart ───────────────────────────────
chrome.runtime.onStartup.addListener(async () => {
  const auto = await getAutoEnabled();
  updateBadge(auto);
  if (auto) {
    console.log('[GasBG] Restore auto scanning setelah browser restart');
    await startOffscreen();
  }
});

// ── Set badge saat SW pertama load ─────────────────────────────
chrome.storage.local.get('autoEnabled', (d) => updateBadge(!!d.autoEnabled));

// ── Helpers ─────────────────────────────────────────────────────
async function startOffscreen() {
  const settings = await getGasSettings();
  await ensureOffscreen();
  // Kirim settings langsung dalam message — tidak perlu offscreen baca storage sendiri
  await new Promise(r => setTimeout(r, 200));
  chrome.runtime.sendMessage({ type: 'START_AUTO', settings }).catch(() => {});
}

async function sendToOffscreen(command, settings) {
  await ensureOffscreen();
  await new Promise(r => setTimeout(r, 200));
  chrome.runtime.sendMessage({ type: command, settings }).catch(() => {});
}

async function ensureOffscreen() {
  if (await hasDocument()) return;
  if (offscreenCreating) {
    await offscreenCreating;
    return;
  }
  offscreenCreating = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['DOM_SCRAPING'],
    justification: 'Fetch EVM gas prices in background'
  });
  await offscreenCreating;
  offscreenCreating = null;
}

async function stopOffscreen() {
  if (!(await hasDocument())) return;
  chrome.runtime.sendMessage({ type: 'STOP_AUTO' }).catch(() => {});
  await new Promise(r => setTimeout(r, 100));
  await chrome.offscreen.closeDocument();
}

async function hasDocument() {
  const list = await self.clients.matchAll();
  return list.some(c => c.url.includes('offscreen.html'));
}
