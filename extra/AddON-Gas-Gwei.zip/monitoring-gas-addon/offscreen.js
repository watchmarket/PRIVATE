/* Gas Monitor - Offscreen Worker
 * Menerima settings dari background.js (tidak baca storage sendiri).
 * Fetch gas prices, kirim hasil ke background untuk disimpan & diteruskan ke popup.
 */

const CHAINS = [
  { key: 'ethereum', chainId: 1,     llama: 'ethereum', priceSymbol: 'ETHUSDT', swapGas: 356190, transferGas: 65000 },
  { key: 'bsc',      chainId: 56,    llama: 'bsc',      priceSymbol: 'BNBUSDT', swapGas: 250000, transferGas: 65000, fixedGwei: 0.1 },
  { key: 'polygon',  chainId: 137,   llama: 'polygon',  priceSymbol: 'POLUSDT', priceFallback: 'MATICUSDT', swapGas: 250000, transferGas: 65000 },
  { key: 'arbitrum', chainId: 42161, llama: 'arbitrum', priceSymbol: 'ETHUSDT', swapGas: 250000, transferGas: 65000 },
  { key: 'base',     chainId: 8453,  llama: 'base',     priceSymbol: 'ETHUSDT', swapGas: 250000, transferGas: 65000 },
];

const REQUEST_TIMEOUT = 8000;
const bnUrl    = (id)    => `https://api.blocknative.com/gasprices/blockprices?chainid=${id}`;
const llamaUrl = (chain) => `https://rpc.llama-rpc.com/${chain}?source=llamaswap`;
const binanceUrl = (syms) => `https://api.binance.com/api/v3/ticker/price?symbols=${encodeURIComponent(JSON.stringify(syms))}`;

// Default settings — di-override oleh pesan dari background
let settings = {
  refreshSec: 30,
  bnKey: '',
  bnEnabled: true,
  llEnabled: true,
  enabledChainsBn:  CHAINS.map(c => c.key),
  enabledChainsRpc: CHAINS.map(c => c.key)
};
let timer = null;
let priceCache = { data: null, ts: 0 };

// ── Message Listener ─────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {

  if (msg.type === 'START_AUTO') {
    if (msg.settings) {
      settings = { ...settings, ...msg.settings };
      // Hapus enabledChains usang jika sudah ada versi spesifik source
      if (msg.settings.enabledChainsBn || msg.settings.enabledChainsRpc) {
        delete settings.enabledChains;
      }
    }
    stopTimer();
    fetchAndSave();
    timer = setInterval(fetchAndSave, (settings.refreshSec || 30) * 1000);
    sendResponse({ ok: true });
  }

  else if (msg.type === 'STOP_AUTO') {
    stopTimer();
    sendResponse({ ok: true });
  }

  else if (msg.type === 'FETCH_ONCE') {
    if (msg.settings) {
      settings = { ...settings, ...msg.settings };
      if (msg.settings.enabledChainsBn || msg.settings.enabledChainsRpc) {
        delete settings.enabledChains;
      }
    }
    fetchAndSave();
    sendResponse({ ok: true });
  }

  else if (msg.type === 'APPLY_SETTINGS') {
    if (msg.settings) {
      settings = { ...settings, ...msg.settings };
      if (msg.settings.enabledChainsBn || msg.settings.enabledChainsRpc) {
        delete settings.enabledChains;
      }
    }
    stopTimer();
    fetchAndSave();
    timer = setInterval(fetchAndSave, (settings.refreshSec || 30) * 1000);
    sendResponse({ ok: true });
  }
});

function stopTimer() {
  if (timer) { clearInterval(timer); timer = null; }
}

// ── Fetch Helpers ────────────────────────────────────────────────
async function getJSON(url, opts = {}) {
  const sig = AbortSignal.timeout(REQUEST_TIMEOUT);
  const res = await fetch(url, { ...opts, signal: sig });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fetchPrices() {
  const now = Date.now();
  if (priceCache.data && (now - priceCache.ts) < 10000) return priceCache.data;
  
  // Ambil gabungan (union) dari chain yang aktif di BN maupun RPC
  const bnSet  = settings.enabledChainsBn  || settings.enabledChains || [];
  const rpcSet = settings.enabledChainsRpc || settings.enabledChains || [];
  const union  = [...new Set([...bnSet, ...rpcSet])];
  
  const active = CHAINS.filter(c => union.includes(c.key));
  const syms = [...new Set(active.flatMap(c => [c.priceSymbol, c.priceFallback].filter(Boolean)))];
  try {
    const data = await getJSON(binanceUrl(syms));
    const map = {};
    (data || []).forEach(r => { if (r?.symbol && r?.price) map[r.symbol] = Number(r.price); });
    priceCache = { data: map, ts: now };
    return map;
  } catch { return priceCache.data || {}; }
}

async function fetchBlocknative(chain) {
  if (chain.fixedGwei != null) return { gasGwei: chain.fixedGwei };
  const headers = settings.bnKey ? { Authorization: settings.bnKey } : {};
  const res = await getJSON(bnUrl(chain.chainId), { headers });
  const bp  = res?.blockPrices?.[0] || {};
  const est = (bp.estimatedPrices || []).find(p => p.confidence === 70) || (bp.estimatedPrices || [])[0] || {};
  const raw = est?.price ?? est?.maxFeePerGas ?? null;
  const g = Number(raw);
  return { gasGwei: Number.isFinite(g) ? g : null };
}

async function fetchLlama(chain) {
  if (chain.fixedGwei != null) return { gasGwei: chain.fixedGwei };
  const res = await getJSON(llamaUrl(chain.llama), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_gasPrice', params: [] })
  });
  const hex = res?.result;
  return { gasGwei: hex ? Number(BigInt(hex)) / 1e9 : null };
}

function computeCosts(gasGwei, chain, priceUsd) {
  if (gasGwei == null || priceUsd == null) return { swapUsd: null, transferUsd: null };
  const gp = gasGwei * 1e-9;
  return { swapUsd: gp * chain.swapGas * priceUsd, transferUsd: gp * chain.transferGas * priceUsd };
}

// ── Main Fetch ───────────────────────────────────────────────────
async function fetchAndSave() {
  const bnSet  = settings.enabledChainsBn  || settings.enabledChains || [];
  const rpcSet = settings.enabledChainsRpc || settings.enabledChains || [];
  const union  = [...new Set([...bnSet, ...rpcSet])];
  
  const active = CHAINS.filter(c => union.includes(c.key));
  if (active.length === 0) return;

  const result = { bn: {}, rpc: {}, timestamp: Date.now() };

  try {
    const prices = await fetchPrices();

    const tasks = active.flatMap(chain => {
      const pu = prices[chain.priceSymbol] ?? prices[chain.priceFallback] ?? null;
      const out = [];

      // Fetch BN jika source ON dan chain ini aktif di BN
      if (settings.bnEnabled !== false && bnSet.includes(chain.key)) {
        out.push(
          fetchBlocknative(chain)
            .then(({ gasGwei }) => { result.bn[chain.key] = { gasGwei, ...computeCosts(gasGwei, chain, pu) }; })
            .catch(() => { result.bn[chain.key] = { gasGwei: null, swapUsd: null, transferUsd: null }; })
        );
      }

      // Fetch RPC jika source ON dan chain ini aktif di RPC
      if (settings.llEnabled !== false && rpcSet.includes(chain.key)) {
        out.push(
          fetchLlama(chain)
            .then(({ gasGwei }) => { result.rpc[chain.key] = { gasGwei, ...computeCosts(gasGwei, chain, pu) }; })
            .catch(() => { result.rpc[chain.key] = { gasGwei: null, swapUsd: null, transferUsd: null }; })
        );
      }

      return out;
    });

    await Promise.allSettled(tasks);
  } catch (_) {}

  // Kirim ke background untuk disimpan ke storage & diteruskan ke popup
  chrome.runtime.sendMessage({ type: 'SAVE_GAS_DATA', data: result }).catch(() => {});
}
