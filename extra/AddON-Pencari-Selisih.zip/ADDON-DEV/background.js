importScripts('config.js');

let offscreenCreating = null;
let currentAppTabId = null;
let offscreenDocExists = false; // Cache flag: skip clients.matchAll() setiap alarm

// ── STATE: Persist ke storage agar survive service worker restart ──
async function getIsScanning() {
  return new Promise(resolve => {
    chrome.storage.local.get(['isScanning', 'scanMode', 'cycleCount'], r => resolve({
      status: !!r.isScanning,
      mode: r.scanMode || 'once',
      cycleCount: r.cycleCount || 0
    }));
  });
}
async function setIsScanning(val, mode = null) {
  const data = { isScanning: val };
  if (mode) data.scanMode = mode;
  if (val === true) data.cycleCount = 0; // Reset saat start baru
  return new Promise(resolve => chrome.storage.local.set(data, resolve));
}

// ── KEEP ALIVE: Alarm setiap 25 detik untuk cegah SW terminate ──
chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 }); // ~24 detik

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'keepAlive') return;
  const { status: scanning } = await getIsScanning();
  if (!scanning) return;

  // Pastikan offscreen document masih hidup, restart jika mati
  if (!(await hasDocument())) {
    console.log('[BG] Offscreen mati saat scanning, restart...');
    await setupOffscreenDocument('offscreen.html', 'START_LOOP');
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'TOGGLE_SCAN') {
    const scanning = message.status;
    setIsScanning(scanning, scanning ? 'auto' : null).then(() => {
      if (scanning) {
        chrome.storage.local.remove(['lastScanCache', 'currentProfitCount']);
        chrome.action.setIcon({ path: "icons/favicon-auto.png" }).catch(() => { });
        chrome.action.setBadgeText({ text: "" });
        chrome.action.setBadgeBackgroundColor({ color: "#198754" });
        setupOffscreenDocument('offscreen.html', 'START_LOOP');
      } else {
        chrome.action.setIcon({ path: "icons/favicon.png" }).catch(() => { });
        chrome.action.setBadgeText({ text: "" });
        closeOffscreenDocument();
      }
    });
    sendResponse({ status: scanning });
  }
  else if (message.type === 'START_SCAN_ONCE') {
    setIsScanning(true, 'once').then(() => {
      chrome.storage.local.remove(['lastScanCache', 'currentProfitCount']);
      chrome.action.setIcon({ path: "icons/favicon-1x.png" }).catch(() => { });
      // chrome.action.setBadgeText({ text: "WAIT" }); // Berubah dari 1X ke WAIT saat mulai
      chrome.action.setBadgeBackgroundColor({ color: "#198754" });
      setupOffscreenDocument('offscreen.html', 'RUN_ONCE').then(() => {
        chrome.runtime.sendMessage({ type: 'SCAN_STATUS', status: true, mode: 'once' }).catch(() => { });
      });
    });
    sendResponse({ status: true });
  }
  else if (message.type === 'SCAN_ONCE_DONE') {
    setIsScanning(false, 'once').then(() => {
      // Tetap biarkan jumlah terakhir muncul
      chrome.action.setIcon({ path: "icons/favicon.png" }).catch(() => { });
      closeOffscreenDocument();
      chrome.runtime.sendMessage({ type: 'SCAN_STATUS', status: false, mode: 'once' }).catch(() => { });
    });
  }
  else if (message.type === 'PROFIT_COUNT_UPDATE') {
    const count = message.count || 0;
    chrome.storage.local.set({ currentProfitCount: count });
    getIsScanning().then(({ mode }) => {
      if (mode === 'auto') {
        chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
      } else {
        chrome.action.setBadgeText({ text: count > 0 ? `${count}` : "" });
      }
    });
  }
  else if (message.type === 'GET_STATUS') {
    getIsScanning().then(result => sendResponse(result));
    return true; // async
  }
  else if (message.type === 'GET_STORAGE') {
    chrome.storage.local.get(message.keys, (result) => {
      sendResponse(result);
    });
    return true;
  }
  else if (message.type === 'SET_STORAGE') {
    chrome.storage.local.set(message.data, () => {
      if (chrome.runtime.lastError) {
        console.error('SET_STORAGE Error:', chrome.runtime.lastError);
      }
      sendResponse({ status: true });
    });
    return true;
  }
  else if (message.type === 'CYCLE_DONE') {
    getIsScanning().then(({ status, mode, cycleCount }) => {
      if (status && mode === 'auto') {
        const newCount = (cycleCount || 0) + 1;
        chrome.storage.local.set({ cycleCount: newCount });
        // Badge tetap menunjukkan jumlah profit terakhir dari cycle ini
      }
    });
  }
  else if (message.type === 'RESET_BADGE') {
    chrome.action.setBadgeText({ text: "" });
    chrome.action.setIcon({ path: "icons/favicon.png" }).catch(() => { });
    sendResponse({ status: true });
  }
  else if (message.type === 'GET_CURRENT_RESULTS') {
    getIsScanning().then(({ status: scanning }) => {
      if (!scanning) sendResponse({ lastScanCache: null });
      // jika scanning, offscreen.js yang jawab
    });
    return true;
  }
  else if (message.type === 'OPEN_APP_TAB') {
    if (currentAppTabId !== null) {
      chrome.tabs.get(currentAppTabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          openNewTab(sendResponse);
        } else {
          chrome.tabs.update(currentAppTabId, { active: true });
          chrome.windows.update(tab.windowId, { focused: true });
          sendResponse({ status: 'focused', tabId: currentAppTabId });
        }
      });
    } else {
      openNewTab(sendResponse);
    }
    return true; // async
  }
  else if (message.type === 'CHECK_TAB_OPEN') {
    if (currentAppTabId !== null) {
      chrome.tabs.get(currentAppTabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          currentAppTabId = null;
          sendResponse({ isOpen: false });
        } else {
          sendResponse({ isOpen: true, tabId: currentAppTabId });
        }
      });
    } else {
      sendResponse({ isOpen: false });
    }
    return true;
  }
});

function openNewTab(sendResponse) {
  chrome.tabs.create({ url: 'popup.html' }, (tab) => {
    currentAppTabId = tab.id;
    sendResponse({ status: 'opened', tabId: tab.id });
  });
}

// Pantau jika tab ditutup
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === currentAppTabId) {
    currentAppTabId = null;
  }
});


// ── Saat extension pertama install/update: restore scan jika sebelumnya aktif ──
chrome.runtime.onStartup.addListener(async () => {
  const { status: scanning, mode } = await getIsScanning();
  if (scanning && mode === 'auto') {
    console.log('[BG] Restore scanning setelah browser restart');
    await setupOffscreenDocument('offscreen.html', 'START_LOOP');
  }
});

async function setupOffscreenDocument(path, command) {
  if (await hasDocument()) {
    chrome.runtime.sendMessage({ type: command }).catch(() => { });
    return;
  }
  if (offscreenCreating) {
    await offscreenCreating;
  } else {
    offscreenCreating = chrome.offscreen.createDocument({
      url: path,
      reasons: ['DOM_SCRAPING', 'AUDIO_PLAYBACK'],
      justification: 'Fetch prices and play background notification sounds'
    });
    await offscreenCreating;
    offscreenCreating = null;
    offscreenDocExists = true; // Set flag setelah berhasil dibuat
  }
  chrome.runtime.sendMessage({ type: command }).catch(() => { });
}

async function closeOffscreenDocument() {
  if (!(await hasDocument())) return;
  chrome.runtime.sendMessage({ type: 'STOP_LOOP' }).catch(() => { });
  await chrome.offscreen.closeDocument();
  offscreenDocExists = false; // Reset flag setelah ditutup
}

async function hasDocument() {
  if (offscreenDocExists) return true; // Cache hit: skip clients.matchAll()
  const matchedClients = await clients.matchAll();
  offscreenDocExists = matchedClients.some(c => c.url.includes('offscreen.html'));
  return offscreenDocExists;
}
