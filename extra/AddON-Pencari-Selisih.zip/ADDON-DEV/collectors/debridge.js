window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.debridge = {
  /**
   * Fetch quote dari deBridge (DLN / deSwap)
   */
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 0.5) {
    try {
      const srcChainId = chainInfo.Kode_Chain;
      const dstChainId = chainInfo.Kode_Chain;

      // Convert human amount to base units (Wei)
      // Menggunakan BigInt-safe string conversion
      const amountInWei = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });

      const params = new URLSearchParams({
        chainId: srcChainId.toString(),
        tokenIn: tokenIn,
        tokenInAmount: amountInWei,
        tokenOut: tokenOut,
        tokenOutRecipient: wallet || '0x0000000000000000000000000000000000000000',
        slippage: slippage.toString(),
        srcChainPriorityLevel: 'normal',
        referralCode: '4850'
      });

      const url = `https://deswap.debridge.finance/v1.0/chain/transaction?${params.toString()}`;


      const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(`deBridge API Error: ${res.status} - ${errText.substring(0, 100)}`);
      }

      const data = await res.json();

      const outAmount = data.tokenOut?.amount;
      if (!outAmount) {
        return {
          price: 0,
          feeUsd: 0,
          routeTool: 'DBR_NONE',
          isError: true,
          errorMsg: 'Data quote tidak lengkap dalam response'
        };
      }

      const amountOutHuman = parseFloat(outAmount) / Math.pow(10, decOut);

      // Identifikasi DEX/Aggregator pemenang
      let routeTool = 'DEBRIDGE';
      if (data.comparedAggregators && Array.isArray(data.comparedAggregators)) {
        // Cari yang amount-nya sama dengan tokenOut.amount
        const winner = data.comparedAggregators.find(a => a.amount === outAmount);
        if (winner && winner.name) {
          routeTool = `DBR-${winner.name.toUpperCase()}`;
        }
      }

      // Estimasi biaya transaksi dalam USD
      const feeUsd = parseFloat(data.estimatedTransactionFee?.approximateUsdValue || data.protocolFeeApproximateUsdValue || 0);

      return {
        price: amountOutHuman,
        feeUsd,
        routeTool: routeTool
      };


    } catch (e) {
      console.log('deBridge Fetch Error:', e);
      return {
        price: 0,
        feeUsd: 0,
        routeTool: 'DBR_ERR',
        isError: true,
        errorMsg: e.message || 'Request failed'
      };
    }
  }
};
