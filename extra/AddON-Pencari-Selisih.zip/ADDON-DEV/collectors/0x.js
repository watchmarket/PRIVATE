window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.matcha = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const amountInBig = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const chainId = String(chainInfo.Kode_Chain);
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';

      const params = new URLSearchParams({
        chainId: chainId,
        sellToken: tokenIn,
        buyToken: tokenOut,
        sellAmount: amountInBig,
        taker: userAddr,
        slippageBps: String(Math.round(parseFloat(slippage) * 100)),
        tradeSurplusRecipient: userAddr,
        aggregator: '0x'
      });

      const url = `https://api.1delta.io/swap/allowance-holder/quote?${params.toString()}`;
      const response = await fetch(url);
      const data = await response.json();
      if (!data?.buyAmount) throw new Error("Rainbow: No buyAmount");

      const amountOut = parseFloat(data.buyAmount) / Math.pow(10, decOut);
      const feeUsd = parseFloat(data.fees?.gasFee?.amountUSD || data.gasCostUsd || 0) || 0;
      return { price: amountOut, feeUsd, routeTool: 'MATCHA (1DELTA)' };
    } catch (e) {
      console.log('MATCHA Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'MATCHA_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
