window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

/**
 * Zerion DEX Aggregator Collector
 * Flow:
 *   1. GET /zpi/search/query/v1?query={contractAddress} → dapat fungibleId canonical
 *   2. SSE /transaction/stream-swap-quotes/v2?inputFungibleId=...&outputFungibleId=...
 */
const ZERION_CHAIN_MAP = {
  56: 'binance-smart-chain',
  1: 'ethereum',
  137: 'polygon',
  42161: 'arbitrum',
  8453: 'base'
};

const ZERION_HEADERS = {
  'zerion-client-type': 'web-extension',
  'zerion-client-version': '1.38.2'
};

// Cache fungibleId per contract address agar tidak repeat lookup
const _fungibleIdCache = {};

async function _getFungibleId(contractAddress, chainSlug) {
  const key = `${chainSlug}:${contractAddress.toLowerCase()}`;
  if (_fungibleIdCache[key]) return _fungibleIdCache[key];

  // Khusus Native Token: Zerion pakai format chain:native
  if (contractAddress.toLowerCase() === '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee') {
    const nativeId = `${chainSlug}:native`;
    _fungibleIdCache[key] = nativeId;
    return nativeId;
  }

  const url = `https://app.zerion.io/zpi/search/query/v1?query=${contractAddress.toLowerCase()}&currency=usd&limit=10`;
  const res = await fetch(url, {
    headers: ZERION_HEADERS,
    signal: AbortSignal.timeout(5000)
  });
  if (!res.ok) throw new Error(`Zerion search HTTP ${res.status}`);

  const json = await res.json();
  const fungibles = json?.data?.fungibles || [];
  
  // Cari yang match dengan chain target
  const fungible = fungibles.find(f => {
    const fChain = f.relationships?.chain?.data?.id;
    return fChain === chainSlug;
  }) || fungibles[0];

  if (!fungible?.id) throw new Error(`Fungible ID tidak ditemukan untuk ${contractAddress} di ${chainSlug}`);

  _fungibleIdCache[key] = fungible.id;
  return fungible.id;
}

// Global semaphore — max 2 concurrent SSE connections ke Zerion
const ZERION_MAX_CONCURRENT = 2;
let _zerionActive = 0;
const _zerionQueue = [];

function _acquireZerion() {
  return new Promise(resolve => {
    if (_zerionActive < ZERION_MAX_CONCURRENT) {
      _zerionActive++;
      resolve();
    } else {
      _zerionQueue.push(resolve);
    }
  });
}

function _releaseZerion() {
  const next = _zerionQueue.shift();
  if (next) {
    next();
  } else {
    _zerionActive--;
  }
}

window.App.collectors.zerion = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, _decIn, _decOut, wallet, slippage = 1) {
    const chainId = chainInfo.Kode_Chain;
    const inputChain = ZERION_CHAIN_MAP[chainId];
    if (!inputChain) {
      return { price: 0, feeUsd: 0, routeTool: 'ZR_UNSUPPORTED', isError: true, errorMsg: `Chain ${chainId} tidak didukung Zerion` };
    }

    // Step 1: Lookup fungible IDs
    let fungibleIn, fungibleOut;
    try {
      [fungibleIn, fungibleOut] = await Promise.all([
        _getFungibleId(tokenIn, inputChain),
        _getFungibleId(tokenOut, inputChain)
      ]);
    } catch (e) {
      return { price: 0, feeUsd: 0, routeTool: 'ZR_ID_ERR', isError: true, errorMsg: e.message };
    }

    const userAddr = wallet || '0x0000000000000000000000000000000000000000';

    const rawAmountStr = amountIn.toString();

    const params = new URLSearchParams({
      currency: 'usd',
      inputChain: inputChain,
      from: userAddr,
      inputFungibleId: fungibleIn,
      outputFungibleId: fungibleOut,
      inputAmount: rawAmountStr,
      slippage: slippage.toString()
    });

    const url = `https://zpi.zerion.io/transaction/stream-swap-quotes/v2?${params.toString()}`;

    // Step 2: Acquire SSE slot sebelum buka koneksi
    await _acquireZerion();

    try {
      return new Promise(async (resolve) => {
        const quotes = [];
        let done = false;
        const controller = new AbortController();

        const finish = (result) => {
          if (done) return;
          done = true;
          clearTimeout(timer);
          controller.abort();
          _releaseZerion();
          resolve(result);
        };

        const timer = setTimeout(() => {
          if (!done) {
            if (quotes.length > 0) {
              quotes.sort((a, b) => b.price - a.price);
              finish({ ...quotes[0], allResults: quotes });
            } else {
              finish({ price: 0, feeUsd: 0, routeTool: 'ZR_TIMEOUT', isError: true, errorMsg: 'Zerion stream timeout' });
            }
          }
        }, 8000);

        try {
          const response = await fetch(url, {
            headers: { ...ZERION_HEADERS, 'Accept': 'text/event-stream' },
            signal: controller.signal
          });
          if (!response.ok) throw new Error(`HTTP ${response.status}`);

          const reader = response.body.getReader();
          const decoder = new TextDecoder();
          let buffer = '';
          let currentEvent = '';
          let streamEnded = false;

          while (true) {
            const { value, done: streamDone } = await reader.read();
            if (streamDone || done) {
              reader.cancel().catch(() => {});
              break;
            }

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop();

            for (const line of lines) {
              const trimmed = line.trim();

              if (trimmed.startsWith('event:')) {
                currentEvent = trimmed.slice(6).trim();
                continue;
              }

              if (!trimmed.startsWith('data:')) continue;

              if (currentEvent === 'end') {
                streamEnded = true;
                break;
              }

              const dataStr = trimmed.replace(/^data:\s*/, '');
              if (!dataStr || dataStr === 'null' || dataStr === '[DONE]') continue;

              try {
                const msg = JSON.parse(dataStr);
                if (!msg) continue;

                const items = Array.isArray(msg)
                  ? msg
                  : (msg.data && Array.isArray(msg.data) ? msg.data : [msg]);

                for (const item of items) {
                  if (!item) continue;

                  const q = item.attributes || item;

                  // outputAmount.quantity dari Zerion ZPI v2 sudah human-readable (bukan raw wei)
                  let price = 0;
                  if (q.outputAmount && typeof q.outputAmount === 'object') {
                    const qtyAfterFees = parseFloat(q.outputAmountAfterFees?.quantity || '0');
                    const qty = parseFloat(q.outputAmount.quantity || '0');
                    price = qtyAfterFees > 0 ? qtyAfterFees : qty;
                  } else {
                    price = parseFloat(
                      q.net_output_amount ?? q.netOutputAmount ?? q.toAmount ?? q.output_amount ?? q.amount_out ?? q.buyAmount ?? q.receiveAmount ?? 0
                    ) || 0;
                  }

                  if (!price || price <= 0) continue;

                  // protocolFee + bridgeFee (relay dan sejenisnya memiliki keduanya)
                  let feeUsd = 0;
                  if (q.protocolFee?.amount?.usdValue != null) {
                    feeUsd += parseFloat(q.protocolFee.amount.usdValue) || 0;
                  }
                  if (q.bridgeFee?.amount?.usdValue != null) {
                    feeUsd += parseFloat(q.bridgeFee.amount.usdValue) || 0;
                  }
                  if (!feeUsd) {
                    feeUsd = parseFloat(
                      q.fee?.valueUsd ?? q.fee?.value_usd ?? q.estimated_fee_fiat_value ?? q.estimatedFeeFiatValue ?? 0
                    ) || 0;
                  }

                  const providerRaw = q.contractMetadata?.name || q.contractMetadata?.id || q.provider?.name || q.provider || 'Zerion';
                  const routeTool = `ZR-${providerRaw.toUpperCase()}`;

                  const existing = quotes.find(x => x.routeTool === routeTool);
                  if (!existing) {
                    quotes.push({ price, feeUsd, routeTool });
                  } else if (price > existing.price) {
                    existing.price = price;
                    existing.feeUsd = feeUsd;
                  }
                }
              } catch (_e) {
                // chunk malformed / heartbeat — skip
              }
            }

            if (streamEnded) {
              reader.cancel().catch(() => {});
              break;
            }
          }

          if (!done) {
            if (quotes.length > 0) {
              quotes.sort((a, b) => b.price - a.price);
              finish({ ...quotes[0], allResults: quotes });
            } else {
              finish({ price: 0, feeUsd: 0, routeTool: 'ZR_EMPTY', isError: true, errorMsg: 'Tidak ada quote diterima' });
            }
          }
        } catch (err) {
          if (!done) {
            if (quotes.length > 0) {
              quotes.sort((a, b) => b.price - a.price);
              finish({ ...quotes[0], allResults: quotes });
            } else {
              const isAbort = err.name === 'AbortError';
              finish({ price: 0, feeUsd: 0, routeTool: isAbort ? 'ZR_ABORT' : 'ZR_ERR', isError: true, errorMsg: err.message });
            }
          }
        }
      });
    } catch (e) {
      console.error('Zerion Collector Fatal Error:', e);
      _releaseZerion();
      return { price: 0, feeUsd: 0, routeTool: 'ZR_FATAL', isError: true, errorMsg: e.message };
    }
  }
};
