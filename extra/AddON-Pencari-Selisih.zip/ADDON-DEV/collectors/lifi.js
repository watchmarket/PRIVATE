window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.lifi = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const amountInWei = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';
      const gasPrice = Number(localStorage.getItem('gasGWEI') || 0);

      const body = {
        chainId: Number(chainInfo.Kode_Chain),
        aggregatorSlug: 'lifi',
        sender: userAddr,
        inToken: {
          chainId: Number(chainInfo.Kode_Chain),
          type: 'TOKEN',
          address: tokenIn.toLowerCase(),
          decimals: Number(decIn)
        },
        outToken: {
          chainId: Number(chainInfo.Kode_Chain),
          type: 'TOKEN',
          address: tokenOut.toLowerCase(),
          decimals: Number(decOut)
        },
        amountInWei: amountInWei.toString(),
        slippageBps: String(Math.round(parseFloat(slippage) * 100)),
        gasPriceGwei: gasPrice
      };

      const response = await fetch('https://bzvwrjfhuefn.up.railway.app/swap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await response.json();
      if (!data?.amountOutWei) throw new Error("Invalid SWOOP response");

      const amountOut = parseFloat(data.amountOutWei) / Math.pow(10, decOut);
      const feeUsd = parseFloat(
        data.gasCostUsd ||
        data.gasUsdAmount ||
        data.gasEstimateUSD ||
        data.gasFeeUsd ||
        data.feeUsd ||
        data.gas?.usdValue ||
        0
      ) || 0;

      return { price: amountOut, feeUsd, routeTool: 'LIFI (SWOOP)' };
    } catch (e) {
      console.log('LIFI Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'LIFI_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
