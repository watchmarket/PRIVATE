window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.lifi = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    // Detect direction (DTC: Stable -> Coin)
    const STABLES = ['0x67b725d7e342d7b611fa85e859df9697d9378b2e', '0x55d398326f99059ff775485246999027b3197955', '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d', '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c'];
    const isDTC = STABLES.includes(tokenIn.toLowerCase());

    try {
      const amountInWei = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const chainIdStr = String(chainInfo.Kode_Chain);
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';

      const params = new URLSearchParams({
        fromChain: chainIdStr,
        toChain: chainIdStr,
        fromToken: tokenIn,
        toToken: tokenOut,
        amount: amountInWei.toString(),
        fromAddress: userAddr,
        slippage: slippage.toString()
      });

      const url = `https://temple-api-evm.prod.templewallet.com/api/swap-route?${params.toString()}`;
      const response = await fetch(url, {
        headers: { 'Content-Type': 'application/json; charset=utf-8' }
      });
      const data = await response.json();
      if (!data?.toAmount) throw new Error("Invalid Temple response");

      const amountOut = parseFloat(data.toAmount) / Math.pow(10, decOut);
      const feeUsd = parseFloat(data.gasCostUSD || 0) || 0.5;
      return { price: amountOut, feeUsd, routeTool: 'LIFI (Temple)' };
    } catch (e) {
      console.log('LIFI Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'LIFI_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
