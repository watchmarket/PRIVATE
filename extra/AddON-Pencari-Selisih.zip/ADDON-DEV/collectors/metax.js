window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.metax = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const amountInBig = (amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const chainId = String(chainInfo.Kode_Chain);
      const userWallet = wallet || "0x0000000000000000000000000000000000000000";

      const params = new URLSearchParams({
        walletAddress: userWallet,
        destWalletAddress: userWallet,
        srcChainId: chainId,
        destChainId: chainId,
        srcTokenAddress: tokenIn,
        destTokenAddress: tokenOut,
        srcTokenAmount: amountInBig,
        insufficientBal: 'true',
        resetApproval: 'false',
        gasIncluded: 'true',
        slippage: slippage.toString()
      });

      const url = `https://bridge.api.cx.metamask.io/getQuoteStream?${params.toString()}`;

      return new Promise((resolve) => {
        const allQuotes = [];
        let done = false;
        const es = new EventSource(url);

        const finalize = () => {
          if (done) return;
          done = true;
          es.close();
          if (allQuotes.length > 0) {
            allQuotes.sort((a, b) => b.price - a.price);
            resolve({ ...allQuotes[0], allResults: allQuotes });
          } else {
            resolve({ price: 0, feeUsd: 0, routeTool: 'METAX_ERR', isError: true, errorMsg: 'Tidak ada quote diterima dari stream' });
          }
        };

        const timeoutId = setTimeout(finalize, 6000);

        const handleQuoteData = (eventData) => {
          if (done) return;
          try {
            const data = JSON.parse(eventData);
            const q = data.quote || data;
            const rawAmtOut = q.buyAmount || q.destTokenAmount || q.toTokenAmount || 0;

            if (rawAmtOut > 0) {
              const amtOut = parseFloat(rawAmtOut) / Math.pow(10, decOut);
              const feeUsd = parseFloat(q.priceData?.totalFeeAmountUsd || q.estimatedGasFeeUsd || q.feeUsd || 0);

              const aggName = (q.aggregator || q.bridgeId || 'Agg').toUpperCase();
              const existing = allQuotes.find(r => r.routeTool === `MM-${aggName}`);
              if (!existing) allQuotes.push({ price: amtOut, feeUsd, routeTool: `MM-${aggName}`, isError: false });
              else if (amtOut > existing.price) { existing.price = amtOut; existing.feeUsd = feeUsd; }
            }
          } catch (e) { }
        };

        es.onmessage = (event) => handleQuoteData(event.data);
        es.addEventListener('quote', (event) => handleQuoteData(event.data));

        es.onerror = finalize;
      });
    } catch (e) {
      console.log('METAX Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'ERROR_METAX', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
