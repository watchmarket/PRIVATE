window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

/**
 * CTRL (XDEFI) DEX Aggregator — MetaDEX Collector
 * Endpoint  : https://gql-router.xdefi.services/graphql
 * Chain fmt : "CHAIN.0xTokenAddress"  (BSC, ETH, POLYGON, ARBITRUM, BASE)
 * Amount    : human-readable (misal "100", bukan wei)
 * MetaDEX   : return allResults[] agar post-filter sub-provider bisa bekerja
 */
window.App.collectors.ctrl = {

  _chainLabel(chainInfo) {
    const map = { 56: 'BSC', 1: 'ETH', 137: 'POLYGON', 42161: 'ARBITRUM', 8453: 'BASE' };
    return map[chainInfo.Kode_Chain] || null;
  },

  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const chainLabel = this._chainLabel(chainInfo);
      if (!chainLabel) throw new Error(`CTRL: Chain ${chainInfo.Kode_Chain} tidak didukung`);

      // CTRL menerima amount dalam unit utuh (bukan wei)
      const amountSource = amountIn.toString();
      const userAddr     = wallet || '0x0000000000000000000000000000000000000000';
      const slippageStr  = String(parseFloat(slippage) || 1);

      const srcToken  = `${chainLabel}.${tokenIn.toLowerCase()}`;
      const destToken = `${chainLabel}.${tokenOut.toLowerCase()}`;

      const query = `{
        routingV2 {
          routeV2(
            srcToken: "${srcToken}"
            destToken: "${destToken}"
            amountSource: "${amountSource}"
            slippage: "${slippageStr}"
            addresses: [{ chain: "${chainLabel}", address: "${userAddr}" }]
            destAddress: "${userAddr}"
            infiniteApproval: false
            isOptedIn: false
            isLedgerLive: false
          ) {
            errorBuildingRoute
            tradesRoute {
              amountIn
              amountOut
              fee {
                networkFeeDollar
              }
              provider {
                id
                name
              }
            }
          }
        }
      }`;

      const response = await fetch('https://gql-router.xdefi.services/graphql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
        signal: AbortSignal.timeout(8000),
      });

      const data = await response.json();

      if (data.errors?.length) {
        throw new Error(`CTRL GQL: ${data.errors[0].message}`);
      }

      const routeData = data?.data?.routingV2?.routeV2;
      if (!routeData) throw new Error('CTRL: No routeV2 in response');
      if (routeData.errorBuildingRoute) throw new Error(`CTRL: ${routeData.errorBuildingRoute}`);

      const trades = routeData.tradesRoute || [];
      if (trades.length === 0) throw new Error('CTRL: tradesRoute kosong');

      // ── amountOut adalah output dari hop terakhir ────────────────
      const last      = trades[trades.length - 1];
      const amountOut = parseFloat(last.amountOut);
      if (!amountOut || amountOut <= 0) throw new Error('CTRL: amountOut tidak valid');

      // ── Total gas fee semua hop ───────────────────────────────────
      const feeUsd = trades.reduce((sum, t) => sum + parseFloat(t.fee?.networkFeeDollar || 0), 0);

      // ── Provider dari trade pertama (DEX/bridge yang dipakai) ────
      const providerRaw  = trades[0]?.provider?.name || trades[0]?.provider?.id || 'CTRL';
      const providerName = providerRaw.toUpperCase();
      const routeTool    = `CTRL-${providerName}`;

      // ── allResults: satu entry per provider unik ─────────────────
      // CTRL biasanya hanya 1 route, tapi kita tetap build allResults
      // agar sistem post-filter (offscreen.js) bisa skip provider yg di-disable
      const seen       = new Set();
      const allResults = [];

      for (const trade of trades) {
        const pName = (trade.provider?.name || trade.provider?.id || 'CTRL').toUpperCase();
        const key   = `CTRL-${pName}`;
        if (seen.has(key)) continue;
        seen.add(key);

        // Harga efektif dari hop ini (pakai amountOut trade terakhir jika ini hop terakhir)
        const hopOut = parseFloat(trade.amountOut);
        allResults.push({
          price:     hopOut > 0 ? amountOut : 0, // semua pakai amountOut final
          feeUsd:    parseFloat(trade.fee?.networkFeeDollar || 0),
          routeTool: key,
        });
      }

      // Pastikan minimal ada 1 entry
      if (allResults.length === 0) {
        allResults.push({ price: amountOut, feeUsd, routeTool });
      }

      // Kembalikan best (= satu-satunya route dari CTRL) + allResults
      return {
        price:    amountOut,
        feeUsd,
        routeTool,
        allResults,
      };
    } catch (e) {
      console.log('CTRL Fetch Error:', e.message);
      return {
        price:     0,
        feeUsd:    0,
        routeTool: 'CTRL_ERR',
        isError:   true,
        errorMsg:  e.message || 'Request failed',
      };
    }
  },
};
