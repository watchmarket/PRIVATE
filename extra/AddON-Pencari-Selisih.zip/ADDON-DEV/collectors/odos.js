window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.odos = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const chainId = Number(chainInfo.Kode_Chain);
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';
      const amountInBig = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });

      const body = {
        chainId: chainId,
        inputTokens: [{ tokenAddress: tokenIn, amount: amountInBig }],
        outputTokens: [{ tokenAddress: tokenOut, proportion: 1 }],
        userAddr: userAddr,
        slippageLimitPercent: slippage,
        referralCode: 0,
        sourceBlacklist: ["Ellipsis Crypto", "Ellipsis Stable"],
        disableRFQs: true,
        compact: true
      };

      const response = await fetch('https://api.odos.xyz/sor/quote/v3', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await response.json();

      const rawOut = Array.isArray(data?.outAmounts) ? data.outAmounts[0] : data?.outAmounts;
      if (!rawOut) throw new Error("Invalid ODOS response: missing outAmounts");

      const amountOut = parseFloat(rawOut) / Math.pow(10, decOut);
      const feeUsd = parseFloat(data?.gasEstimateValue || 0) || 0;

      return { price: amountOut, feeUsd, routeTool: 'ODOS (v3)' };
    } catch (e) {
      console.log('ODOS Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'ODOS_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
