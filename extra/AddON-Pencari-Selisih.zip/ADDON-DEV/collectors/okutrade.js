window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

const OKU_BASE = 'https://accounts.v2.icarus.tools/connect/gfxcafe.oku.account.v2.SimpleSwapServiceV2';
//const OKU_MARKETS = ['cowswap', 'enso', 'icecreamswap', 'kyberswap', 'odos', 'okx', 'oneinch', 'openocean', 'paraswap', 'unizen', 'usor', 'zeroex'];
const OKU_MARKETS = ['enso',  'kyberswap', 'odos', 'okx', 'oneinch', 'openocean', 'paraswap',  'zeroex'];

window.App.collectors.okutrade = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
      const chainId = String(chainInfo.Kode_Chain);
      const slippageBps = Math.round(slippage * 100); // 1% -> 100 bps

      // Step 1: Create Order
      const createRes = await fetch(`${OKU_BASE}/Create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ params: {} }),
        signal: AbortSignal.timeout(5000)
      });
      if (!createRes.ok) throw new Error(`Create gagal: ${createRes.status}`);
      const createData = await createRes.json();
      const orderId = createData.orderId;
      if (!orderId) throw new Error('Tidak ada orderId dari Create');

      // Step 2: UpdateQuoteParams
      const updateRes = await fetch(`${OKU_BASE}/UpdateQuoteParams`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          params: {
            chain: chainId,
            enabledMarkets: OKU_MARKETS,
            inTokenAddress: tokenIn,
            isExactIn: true,
            outTokenAddress: tokenOut,
            slippage: slippageBps,
            tokenAmount: amountIn.toString(),
            usePermit2: true
          }
        }),
        signal: AbortSignal.timeout(5000)
      });
      if (!updateRes.ok) throw new Error(`UpdateQuoteParams gagal: ${updateRes.status}`);

      // Step 3: GetNewQuotes (waitTime = 5 detik)
      const quotesRes = await fetch(`${OKU_BASE}/GetNewQuotes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fetchedRouters: ['cowswap', 'enso', 'icecreamswap', 'kyberswap', 'okx', 'oneinch', 'openocean', 'paraswap', 'unizen'],
          generation: 1,
          orderId,
          waitTime: '5000'
        }),
        signal: AbortSignal.timeout(8000)
      });
      if (!quotesRes.ok) throw new Error(`GetNewQuotes gagal: ${quotesRes.status}`);
      const quotesData = await quotesRes.json();

      // quotes adalah object { routerName: { router, fetched, quote: { inAmount, outAmount, fees: { gasUsdValue } } } }
      const quotesMap = quotesData.quotes || {};
      const allQuotes = [];

      for (const [key, item] of Object.entries(quotesMap)) {
        if (!item || !item.quote) continue;
        const q = item.quote;
        const routerName = (item.router || key || 'OKU').toUpperCase();

        const amountOut = parseFloat(q.outAmount ?? q.netOutAmount ?? q.amountOut ?? 0);
        if (!isFinite(amountOut) || amountOut <= 0) continue;

        const feeUsd = parseFloat(q.fees?.gasUsdValue ?? q.gasUsd ?? q.gasUsdValue ?? 0);

        allQuotes.push({ price: amountOut, feeUsd, routeTool: `OKU-${routerName}` });
      }

      if (allQuotes.length === 0) throw new Error('Tidak ada quote valid dari GetNewQuotes');

      allQuotes.sort((a, b) => b.price - a.price);
      return { ...allQuotes[0], allResults: allQuotes };

    } catch (e) {
      console.log('OKUTRADE Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'OKU_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
