window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.matcha = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    // Detect direction (DTC: Stable -> Coin)
    const STABLES = ['0x67b725d7e342d7b611fa85e859df9697d9378b2e', '0x55d398326f99059ff775485246999027b3197955', '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d', '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c'];
    const isDTC = STABLES.includes(tokenIn.toLowerCase());

    try {
      const amountInBig = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const chainId = String(chainInfo.Kode_Chain);
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';

      const params = new URLSearchParams({
        chainId: chainId,
        sellToken: tokenIn,
        buyToken: tokenOut,
        sellAmount: amountInBig,
        slippage: slippage.toString(),
        fromAddress: userAddr,
        source: '0x',
        allowFallback: 'true',
        currency: 'USD',
        enableNewChainSwaps: 'true'
      });

      const url = `https://swap.p.rainbow.me/v1/quote?${params.toString()}`;
      const response = await fetch(url);
      const data = await response.json();
      if (!data?.buyAmount) throw new Error("Rainbow: No buyAmount");

      const amountOut = parseFloat(data.buyAmount) / Math.pow(10, decOut);
      const feeUsd = parseFloat(data.fees?.gasFee?.amountUSD || 0) || 0.5;
      return { price: amountOut, feeUsd, routeTool: 'MATCHA (Rainbow)' };
    } catch (e) {
      console.log('MATCHA Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'MATCHA_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
