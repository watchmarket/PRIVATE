window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.kyber = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    const amountInBig = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
    const chainStr = String(chainInfo.label).toLowerCase();
    const chainId = Number(chainInfo.Kode_Chain);

    // Determine direction: CTD (EDU -> USDT) or DTC (USDT -> EDU)
    const STABLES = ['0x67b725d7e342d7b611fa85e859df9697d9378b2e', '0x55d398326f99059ff775485246999027b3197955', '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d', '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c'];
    const isDTC = STABLES.includes(tokenIn.toLowerCase());

    try {
      const includedSources = 'uniswap,uniswapv3,sushiswap,pancake,kyberswap,curve,balancer-v2-stable';
      const url = `https://aggregator-api.kyberswap.com/${chainStr}/api/v1/routes?tokenIn=${tokenIn}&tokenOut=${tokenOut}&amountIn=${amountInBig}&to=${wallet || '0x0000000000000000000000000000000000000000'}&slippageTolerance=${slippage * 100}&includedSources=${encodeURIComponent(includedSources)}&gasInclude=true`;

      const response = await fetch(url);
      const data = await response.json();
      if (!data?.data?.routeSummary) throw new Error("Invalid KyberSwap response");

      const amountOut = data.data.routeSummary.amountOut / Math.pow(10, decOut);
      const respGasUsd = parseFloat(data.data.routeSummary.gasUsd);
      const feeUsd = Number.isFinite(respGasUsd) && respGasUsd > 0 ? respGasUsd : 0.5;
      return { price: amountOut, feeUsd, routeTool: 'KYBER (Aggregator)' };
    } catch (e) {
      console.log('KYBER Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'KYBER_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};
