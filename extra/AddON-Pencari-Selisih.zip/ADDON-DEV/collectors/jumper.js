window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

window.App.collectors.jumper = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 0.003) {
    try {
      const amountInWei = Math.round(amountIn * Math.pow(10, decIn)).toLocaleString('fullwide', { useGrouping: false });
      const chainId = chainInfo.Kode_Chain;
      const userAddr = wallet || '0x0000000000000000000000000000000000000000';

      // Brave Wallet Li.Fi Advanced Routes endpoint
      const urlParams = new URLSearchParams({
        fromToken: tokenIn,
        toToken: tokenOut,
        fromChain: chainId.toString(),
        toChain: chainId.toString(),
        fromAddress: userAddr,
        toAddress: userAddr,
        fromAmount: amountInWei,
        slippage: slippage.toString(),
        fee: '0.0069',
        integrator: 'brave',
        allowExchanges: 'all',
        order: 'CHEAPEST',
        maxPriceImpact: '0.15'
      });

      const body = {
        fromAddress: userAddr,
        fromAmount: amountInWei,
        fromChainId: chainId,
        fromTokenAddress: tokenIn,
        toChainId: chainId,
        toTokenAddress: tokenOut,
        options: {
          integrator: "brave",
          order: "CHEAPEST",
          maxPriceImpact: 0.4,
          jitoBundle: true,
          allowSwitchChain: true,
          executionType: "all"
        }
      };

      const response = await fetch(`https://lifi.wallet.brave.com/v1/advanced/routes?${urlParams.toString()}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (!data.routes || data.routes.length === 0) {
        return { price: 0, feeUsd: 0, routeTool: 'JMP_NONE', isError: true, errorMsg: 'Tidak ada rute tersedia untuk pasangan ini' };
      }

      // Sort by toAmount descending to get the best route (highest output)
      const sortedRoutes = data.routes.sort((a, b) => {
        const amtA = BigInt(a.toAmount || 0);
        const amtB = BigInt(b.toAmount || 0);
        if (amtA > amtB) return -1;
        if (amtA < amtB) return 1;
        return 0;
      });

      // Map semua routes ke format standar (sudah sorted descending)
      const allResults = sortedRoutes.map(route => {
        const p = parseFloat(route.toAmount) / Math.pow(10, decOut);
        const f = parseFloat(route.gasCostUSD || 0);

        const tools = (route.steps || []).map(s => s.tool).filter(t => t);
        const tName = tools.length > 0 ? `JMP-${tools[0].toUpperCase()}` : 'JMP';
        return { price: p, feeUsd: f, routeTool: tName };
      });

      return { ...allResults[0], allResults };
    } catch (e) {
      console.log('Jumper Fetch Error:', e);
      return { price: 0, feeUsd: 0, routeTool: 'JMP_ERR', isError: true, errorMsg: e.message || 'Request failed' };
    }
  }
};

const Logger = {
  enabled: true, // Ubah ke false untuk mematikan semua log console
  context: '',   // Simpan pasangan koin/pair aktif (e.g. BTC/USDT)

  setContext: (ctx) => { Logger.context = ctx ? ` | ${ctx}` : ''; },

  pnl: (d) => {
    if (!Logger.enabled) return;
    const format = (v) => Number.isFinite(v) ? v.toFixed(6).replace(/\.?0+$/, '') : v;
    console.log(`[PNL-LOG] ${d.pair} | DEX: ${d.dex} (${d.dir})`);
    console.log(`├─ 1. Buy on ${d.buyLoc}: ${format(d.buyUnits)} ${d.buySym} (Modal $${d.modal} @ $${format(d.buyPrice)})`);
    console.log(`├─ 2. Sell on ${d.sellLoc}: ${format(d.sellUsd)} USD (Got ${format(d.sellUnits)} ${d.sellSym} @ $${format(d.sellPrice)})`);
    console.log(`└─ Logic: (${format(d.sellUsd)} - ${d.modal}) = ${format(d.pnl)}`);
  },
  dex: (name, msg, val) => {
    if (!Logger.enabled) return;
    console.log(`[DEX-CALC-INFO] ${name}${Logger.context} -> ${msg}: ${val}`);
  },
  raw: (name, data) => {
    if (!Logger.enabled) return;
    console.log(`[DEX-RAW] ${name}${Logger.context}:`, data);
  },
  metaSummary: (name, results, dirSuffix) => {
    if (!Logger.enabled || !results || results.length <= 1) return;
    const suffix = dirSuffix ? ` (${dirSuffix})` : '';
    console.log(`[DEX-SUMMARY] ${name.toUpperCase()}${Logger.context}${suffix} (${results.length} Routes Found)`);
    results.forEach((r, i) => {
      const pfx = (i === results.length - 1) ? '  └─' : '  ├─';
      console.log(`${pfx} ${i + 1}. ${r.routeTool.toUpperCase()} : ${r.price.toFixed(6)} ($${r.feeUsd.toFixed(2)} Fee)`);
    });
  },
  cex: (name, data, url) => {
    if (!Logger.enabled) return;
    if (url) console.log(`[CEX-FETCH]${Logger.context} Requesting: ${url}`);
    if (data) console.log(`[CEX-FETCH]${Logger.context} RAW RESPONSE (${name}):`, data);
  }
};

const Units = {
  /**
   * Mengonversi jumlah human-readable (seperti 1000 USDT) ke unit dasar (Wei) dengan presisi BigInt.
   */
  toBig: (val, dec) => {
    if (!val || isNaN(val)) return 0n;
    // Gunakan 6 desimal sebagai buffer aman untuk float JavaScript sebelum pindah ke BigInt
    const safeDec = Math.min(dec, 6);
    const multiplier = 10 ** safeDec;
    const bigPart = BigInt(Math.round(val * multiplier));
    const remainingDec = BigInt(Math.max(0, dec - safeDec));
    return bigPart * (10n ** remainingDec);
  },

  /**
   * Mengonversi unit dasar (Wei) kembali ke human-readable menggunakan string manipulation untuk menjaga presisi.
   */
  toHuman: (bigVal, dec) => {
    if (bigVal === undefined || bigVal === null) return 0;
    const s = bigVal.toString().padStart(dec + 1, '0');
    const intPart = s.slice(0, -dec) || '0';
    const fracPart = s.slice(-dec);
    // Kita tetap kembalikan parseFloat untuk perhitungan PNL akhir, 
    // tapi proses pemecahan string ini jauh lebih akurat daripada parseFloat(rawWei).
    return parseFloat(intPart + '.' + fracPart);
  }
};
