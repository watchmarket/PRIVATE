window.App = window.App || {};
window.App.collectors = window.App.collectors || {};

const ONEKEY_META_NETWORK_MAP = {
    56: 'evm--56', 1: 'evm--1', 137: 'evm--137',
    42161: 'evm--42161', 8453: 'evm--8453',
};
const ONEKEY_META_PROVIDER_MAP = {
    'swapokx':   'OKX',
    'swap1inch': '1INCH',
    'swap0x':    'MATCHA',
};
const _ONEKEY_META_NATIVE = '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee';

window.App.collectors.onekey = {
  async getQuote(chainInfo, tokenIn, tokenOut, amountIn, decIn, decOut, wallet, slippage = 1) {
    try {
        const chainId = Number(chainInfo.Kode_Chain);
        const networkId = ONEKEY_META_NETWORK_MAP[chainId];
        if (!networkId) return { price: 0, feeUsd: 0, routeTool: 'OK_UNSUPPORTED', isError: true, errorMsg: `Chain ID ${chainId} tidak didukung OneKey` };

        const userAddr = wallet || '0x0000000000000000000000000000000000000000';

        const fromAddr = tokenIn.toLowerCase() === _ONEKEY_META_NATIVE ? '' : tokenIn;
        const toAddr = tokenOut.toLowerCase() === _ONEKEY_META_NATIVE ? '' : tokenOut;

        const params = new URLSearchParams({
            fromTokenAddress:      fromAddr,
            toTokenAddress:        toAddr,
            fromTokenAmount:       amountIn.toString(),
            fromNetworkId:         networkId,
            toNetworkId:           networkId,
            protocol:              'Swap',
            userAddress:           userAddr,
            slippagePercentage:    slippage.toString(),
            autoSlippage:          'true',
            receivingAddress:      userAddr,
            kind:                  'sell',
            denySingleSwapProvider: '',
        });

        const url = `https://swap.onekeycn.com/swap/v1/quote/events?${params}`;

        return new Promise((resolve) => {
            const quotes = [];
            let done = false;
            const es = new EventSource(url);

            const timer = setTimeout(() => {
                if (!done) {
                    done = true;
                    es.close();
                    if (quotes.length > 0) {
                        quotes.sort((a, b) => b.price - a.price);
                        resolve({ ...quotes[0], allResults: quotes });
                    } else {
                        resolve({ price: 0, feeUsd: 0, routeTool: 'OK_TIMEOUT', isError: true, errorMsg: 'Timeout: tidak ada quote diterima dalam 6 detik' });
                    }
                }
            }, 6000);

            es.onmessage = ev => {
                if (done) return;
                try {
                    const msg = JSON.parse(ev.data);
                    if (!msg.data || !Array.isArray(msg.data)) return;

                    for (const item of msg.data) {
                        const providerKey = String(item.info?.provider || '').toLowerCase();
                        if (providerKey === 'swaplifi') continue;
                        if (!item.toAmount) continue;

                        const toAmountHuman = parseFloat(item.toAmount);
                        if (!isFinite(toAmountHuman) || toAmountHuman <= 0) continue;

                        const providerName = (item.info?.providerName || item.info?.provider || 'Dex').toUpperCase();
                        const feeUsd = parseFloat(item.fee?.estimatedFeeFiatValue || item.estimatedFeeFiatValue || 0.5);

                        quotes.push({ price: toAmountHuman, feeUsd, routeTool: `OK-${providerName}` });
                    }

                    if (msg.totalQuoteCount && quotes.length >= msg.totalQuoteCount) {
                        done = true;
                        clearTimeout(timer);
                        es.close();
                        quotes.sort((a, b) => b.price - a.price);
                        resolve({ ...quotes[0], allResults: quotes });
                    }
                } catch { }
            };

            es.onerror = () => {
                if (!done) {
                    done = true;
                    clearTimeout(timer);
                    es.close();
                    if (quotes.length > 0) {
                        quotes.sort((a, b) => b.price - a.price);
                        resolve({ ...quotes[0], allResults: quotes });
                    } else {
                        resolve({ price: 0, feeUsd: 0, routeTool: 'OK_ERR', isError: true, errorMsg: 'SSE connection error, tidak ada quote tersedia' });
                    }
                }
            };
        });
    } catch (e) {
        return { price: 0, feeUsd: 0, routeTool: 'OK_FATAL', isError: true, errorMsg: e.message || 'Fatal error' };
    }
  }
};
