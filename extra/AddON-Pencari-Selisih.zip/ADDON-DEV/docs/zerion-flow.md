# Zerion — Alur Pengambilan Harga Swap

## Gambaran Umum

Zerion menggunakan dua request berantai:

```
[1] Lookup Fungible ID          [2] Stream Swap Quotes (SSE)
 contract address  ──────────►  fungibleId  ──────────►  harga output
```

---

## Input Parameter `getQuote`

| Parameter   | Tipe     | Contoh                                       | Keterangan                              |
|-------------|----------|----------------------------------------------|-----------------------------------------|
| `chainInfo` | Object   | `{ Kode_Chain: 56 }`                         | Info chain, diambil `Kode_Chain`        |
| `tokenIn`   | string   | `"0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d"` | Contract address token input            |
| `tokenOut`  | string   | `"0xb8c77482e45f1f44de1745f52c74426c631bdd52"` | Contract address token output           |
| `amountIn`  | number   | `100`                                        | Jumlah token input, **human-readable**  |
| `wallet`    | string   | `"0xabc..."`                                 | Opsional, default zero address          |
| `slippage`  | number   | `1`                                          | Slippage dalam persen (default 1%)      |

---

## Step 1 — Lookup Fungible ID

Zerion tidak menerima contract address langsung sebagai identifier swap. Setiap token punya **fungibleId** canonical yang harus diambil terlebih dahulu.

### Request

```
GET https://app.zerion.io/zpi/search/query/v1?query={contractAddress}&currency=usd&limit=10
```

**Headers wajib:**
```
zerion-client-type: web-extension
zerion-client-version: 1.38.2
```

### Kasus Khusus: Native Token

Jika `contractAddress === 0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee`, tidak perlu request — langsung pakai format:
```
{chainSlug}:native
contoh: binance-smart-chain:native
```

### Respons & Ekstraksi

```json
{
  "data": {
    "fungibles": [
      {
        "id": "0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d",
        "relationships": {
          "chain": { "data": { "id": "binance-smart-chain" } }
        }
      }
    ]
  }
}
```

Ambil entry yang `relationships.chain.data.id` cocok dengan chain target. Jika tidak ada yang cocok, pakai `fungibles[0]`.

### Cache

Hasil fungibleId di-cache dengan key `{chainSlug}:{contractAddress}` agar request berikutnya untuk token yang sama tidak perlu lookup ulang.

### Chain Slug Map

| Chain ID | Slug Zerion              |
|----------|--------------------------|
| 1        | `ethereum`               |
| 56       | `binance-smart-chain`    |
| 137      | `polygon`                |
| 42161    | `arbitrum`               |
| 8453     | `base`                   |

---

## Step 2 — Stream Swap Quotes (SSE)

### Semaphore Koneksi

Zerion membatasi koneksi SSE. Implementasi menggunakan semaphore maksimal **2 koneksi aktif** secara bersamaan. Request ke-3 dan seterusnya masuk antrian dan baru dieksekusi saat slot kosong.

### Request

```
GET https://zpi.zerion.io/transaction/stream-swap-quotes/v2?{params}
Accept: text/event-stream
```

**Query Parameters:**

| Parameter         | Nilai                      | Contoh                                               |
|-------------------|----------------------------|------------------------------------------------------|
| `currency`        | `usd`                      | `usd`                                                |
| `inputChain`      | chain slug                 | `binance-smart-chain`                                |
| `from`            | wallet address             | `0x0000000000000000000000000000000000000000`         |
| `inputFungibleId` | fungibleId token input     | `0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d`         |
| `outputFungibleId`| fungibleId token output    | `0xb8c77482e45f1f44de1745f52c74426c631bdd52`         |
| `inputAmount`     | jumlah token input         | `100` (bukan wei, langsung human-readable)           |
| `slippage`        | persen slippage            | `1`                                                  |

> **Catatan penting:** `inputAmount` adalah nilai human-readable langsung. Untuk 100 token → kirim `100`. Bukan dikonversi ke raw/wei.

---

## Format SSE Stream

Server mengirim event secara bertahap. Setiap blok SSE terdiri dari:
```
event:{tipe}
data:{payload}

```
(diakhiri baris kosong)

### Tipe Event

| Event    | Data    | Keterangan                                                              |
|----------|---------|-------------------------------------------------------------------------|
| `begin`  | `null`  | Penanda stream dimulai, tidak ada data                                  |
| `update` | `[...]` | Array quote terbaru (akumulatif — setiap update berisi SEMUA quote saat ini) |
| `end`    | `null`  | Penanda stream selesai, semua quote sudah terkirim                      |

### Contoh Satu Blok Update

```
event:update
data:[
  {
    "contractMetadata": { "id": "kyber", "name": "KyberSwap", ... },
    "inputAmount":  { "quantity": "1",                    "usdValue": 1.63 },
    "outputAmount": { "quantity": "0.002525866014177783", "usdValue": 1.61 },
    "outputAmountAfterFees": { "quantity": "", "usdValue": 1.61 },
    "protocolFee": {
      "amount": { "quantity": "0.000016923302294991", "usdValue": 0.0108 }
    },
    "bridgeFee": null,
    "error": { "code": 1, "message": "Input asset balance is not enough..." }
  },
  { ... quote lain ... }
]
```

> **Catatan error:** Field `error` dengan code `1` muncul karena wallet `0x000...` tidak punya saldo. Quote tetap valid untuk keperluan harga — abaikan error ini.

---

## Pengolahan Data Quote

### Ekstraksi Harga Output

`outputAmount.quantity` sudah dalam bentuk **human-readable** (bukan raw wei):

```
priority: outputAmountAfterFees.quantity  (jika > 0)
fallback:  outputAmount.quantity
```

Contoh: `"0.002525866014177783"` → `price = 0.002525866014177783`

Tidak perlu dibagi `10^decimals`.

### Ekstraksi Fee (USD)

```
feeUsd = protocolFee.amount.usdValue
       + bridgeFee.amount.usdValue   ← hanya ada pada provider bridge (contoh: Relay)
```

### Nama Provider (routeTool)

```
sumber: contractMetadata.name  atau  contractMetadata.id
format: "ZR-{NAMA_UPPERCASE}"
contoh: "ZR-KYBERSWAP", "ZR-1INCH", "ZR-0X EXCHANGE"
```

### Deduplikasi & Update

Setiap `event:update` adalah snapshot akumulatif. Jika provider yang sama muncul di update berikutnya dengan harga lebih tinggi, data lama diganti.

---

## Alur Penyelesaian (Finish)

Terdapat tiga kondisi yang mengakhiri proses dan mengembalikan hasil:

```
1. event:end diterima   →  selesai normal, pakai semua quote yang terkumpul
2. Timeout 8 detik      →  pakai quote yang sudah ada (jika ada)
3. Stream error/abort   →  pakai quote yang sudah ada (jika ada), atau return error
```

Hasil akhir adalah quote dengan `price` tertinggi, disertai `allResults` berisi seluruh quote:

```js
{
  price: 0.002534719526949177,   // jumlah tokenOut yang diterima
  feeUsd: 0.0109,                // total biaya protokol dalam USD
  routeTool: "ZR-0X EXCHANGE",  // provider terbaik
  allResults: [                  // semua provider
    { price: 0.002534..., feeUsd: 0.0109, routeTool: "ZR-0X EXCHANGE" },
    { price: 0.002533..., feeUsd: 0.0108, routeTool: "ZR-RELAY" },
    { price: 0.002525..., feeUsd: 0.0108, routeTool: "ZR-KYBERSWAP" },
    ...
  ]
}
```

---

## Error Return

Jika proses gagal total, return object dengan `isError: true`:

| `routeTool`       | Penyebab                                          |
|-------------------|---------------------------------------------------|
| `ZR_UNSUPPORTED`  | Chain ID tidak ada di `ZERION_CHAIN_MAP`          |
| `ZR_ID_ERR`       | Gagal lookup fungibleId (token tidak ditemukan)   |
| `ZR_EMPTY`        | Stream selesai tapi tidak ada quote valid         |
| `ZR_TIMEOUT`      | Tidak ada quote masuk dalam 8 detik               |
| `ZR_ABORT`        | Koneksi di-abort (biasanya karena finish dipanggil lebih dulu) |
| `ZR_ERR`          | Error fetch/network                               |
| `ZR_FATAL`        | Error tak terduga di luar Promise                 |
